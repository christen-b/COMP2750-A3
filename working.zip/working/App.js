import React, { useState } from "react";
import { SafeAreaView, StyleSheet, View, Text, Button } from 'react-native';
import { Picker } from '@react-native-picker/picker';

export default function App() {
  const [picker1SelectedValue, setPicker1SelectedValue] = useState("0"); // Dog price
  const [picker2selectedValue, setPicker2SelectedValue] = useState("0"); // Hours
  const [serviceValue, setServiceValue] = useState("0"); // Service price
  const [quantityValue, setQuantityValue] = useState("0"); // Quantity
  const [calculatedValue, setCalculatedValue] = useState("Press the above button to calculate");

  return (
    <SafeAreaView style={styles.container}>

      <View style={styles.row0}>
        <Text style={styles.heading}> SIGMA DOG CARE </Text>
      </View>
      <View style={styles.row1}>
        <Text style={styles.heading1}> Credit Points Calculator </Text>
      </View>

      <View style={styles.row2}>
        <Picker
          style={styles.picker1}
          selectedValue={picker1SelectedValue}
          onValueChange={(itemValue) => setPicker1SelectedValue(itemValue)}
        >
          <Picker.Item label="Select Dog Name" value="0" />
          <Picker.Item label="Finn-$15" value="15" />
          <Picker.Item label="Bluey-$18" value="18" />
          <Picker.Item label="Jack-$18" value="18" />
          <Picker.Item label="Luna-$18" value="18" />
          <Picker.Item label="Max-$20" value="20" />
        </Picker>

        <Picker
          style={styles.picker2}
          selectedValue={picker2selectedValue}
          onValueChange={(itemValue) => setPicker2SelectedValue(itemValue)}
        >
          <Picker.Item label="Hours of Care" value="0" />
          <Picker.Item label="1 Hour" value="1" />
          <Picker.Item label="2 Hours" value="2" />
          <Picker.Item label="3 Hours" value="3" />
          <Picker.Item label="4 Hours" value="4" />
          <Picker.Item label="5 Hours" value="5" />
        </Picker>
      </View>

      <View style={styles.row3}>
        <Picker
          style={styles.picker1}
          selectedValue={serviceValue}
          onValueChange={(itemValue) => setServiceValue(itemValue)}
        >
          <Picker.Item label="Select a Service" value="0" />
          <Picker.Item label="Grooming-$20" value="20" />
          <Picker.Item label="Walking-$10" value="10" />
          <Picker.Item label="Training-$15" value="15" />
          <Picker.Item label="Sitting-$10" value="10" />
          <Picker.Item label="Boarding-$20" value="20" />
        </Picker>

        <Picker
          style={styles.picker2}
          selectedValue={quantityValue}
          onValueChange={(itemValue) => setQuantityValue(itemValue)}
        >
          <Picker.Item label="Quantity" value="0" />
          <Picker.Item label="1" value="1" />
          <Picker.Item label="2" value="2" />
          <Picker.Item label="3" value="3" />
          <Picker.Item label="4" value="4" />
          <Picker.Item label="5" value="5" />
        </Picker>
      </View>

      <View style={styles.rowFooter}>
        <Text style={styles.footerText}>
          App developed by Christen Bermudez, Ross Medina,
          Valerie Tutureski, Tiantian Xu
        </Text>
      </View>

      <View>
        <Button
          title="CALCULATE"
          onPress={() => {
            const dogCost = parseInt(picker1SelectedValue);
            const hours = parseInt(picker2selectedValue);
            const serviceCost = parseInt(serviceValue);
            const quantity = parseInt(quantityValue);

            if (
              picker1SelectedValue === "0" ||
              picker2selectedValue === "0" ||
              serviceValue === "0" ||
              quantityValue === "0"
            ) {
              setCalculatedValue("Error: Please select values for all fields.");
              return;
            }

            const total = (dogCost * hours) + (serviceCost * quantity);
            setCalculatedValue(`Total: $${total}`);
          }}
        />

        <Text style={[
          styles.heading1,
          calculatedValue.startsWith("Error") && { color: 'red' }
        ]}>
          {calculatedValue}
        </Text>
      </View>

    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#E3D3E3'
  },
  heading: {
    fontSize: 30,
    textAlign: 'center',
    marginTop: 20
  },
  heading1: {
    fontSize: 20,
    textAlign: 'center',
    marginTop: 50
  },
  row0: {
    marginTop: 10
  },
  row1: {
    marginTop: 10
  },
  row2: {
    flexDirection: 'row',
    marginTop: 0
  },
  row3: {
    flexDirection: 'row',
    marginTop: 0
  },
  picker1: {
    flex: 1,
    fontSize: 10
  },
  picker2: {
    flex: 1,
    fontSize: 10
  },
  rowFooter: {
    position: 'absolute',
    bottom: 20,
    width: '100%',
    alignItems: 'center',
  },
  footerText: {
    fontSize: 12,
    textAlign: 'center',
    lineHeight: 16,
  }
});
